-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: fooddash_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `phone_ciphertext` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `address_ciphertext` mediumtext DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `api_token` varchar(255) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `fcm_token_ciphertext` text DEFAULT NULL,
  `fcm_token_hash` char(64) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_hash` char(64) DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `reset_code` varchar(6) DEFAULT NULL,
  `reset_code_hash` char(64) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `mfa_enabled` tinyint(1) DEFAULT 1,
  `login_otp_code` varchar(6) DEFAULT NULL,
  `login_otp_hash` char(64) DEFAULT NULL,
  `login_otp_expires` datetime DEFAULT NULL,
  `token_version` int(11) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `api_token` (`api_token`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (5,'Jan','benzcarllozada123@gmail.com','$argon2id$v=19$m=65536,t=4,p=1$ajhWMUtrZENKM2NITUhrUw$PJoBYzK33J8kcSHcfYmN544ySJLDGD8ZC5mnD6L3KjA','09268158902',NULL,'labangal',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-04-09 15:24:18','2026-04-09 15:24:18',1,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_types`
--

DROP TABLE IF EXISTS `delivery_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `vehicle_type` varchar(30) NOT NULL,
  `size_category` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vehicle_type` (`vehicle_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_types`
--

LOCK TABLES `delivery_types` WRITE;
/*!40000 ALTER TABLE `delivery_types` DISABLE KEYS */;
INSERT INTO `delivery_types` VALUES (1,'Small Order Delivery','motorcycle','small',1,'2026-04-09 07:38:21','2026-04-09 07:38:21'),(2,'Medium Order Delivery','tricycle','medium',1,'2026-04-09 07:38:21','2026-04-09 07:38:21'),(3,'Bulk Order Delivery','cab','bulk',1,'2026-04-09 07:38:21','2026-04-09 07:38:21');
/*!40000 ALTER TABLE `delivery_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drivers`
--

DROP TABLE IF EXISTS `drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drivers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `phone_ciphertext` text DEFAULT NULL,
  `vehicle_type` varchar(50) DEFAULT NULL,
  `license_number` varchar(50) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `api_token` varchar(255) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `fcm_token_ciphertext` text DEFAULT NULL,
  `fcm_token_hash` char(64) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `mfa_enabled` tinyint(1) DEFAULT 1,
  `login_otp_code` varchar(6) DEFAULT NULL,
  `login_otp_hash` char(64) DEFAULT NULL,
  `login_otp_expires` datetime DEFAULT NULL,
  `token_version` int(11) unsigned DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drivers`
--

LOCK TABLES `drivers` WRITE;
/*!40000 ALTER TABLE `drivers` DISABLE KEYS */;
/*!40000 ALTER TABLE `drivers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 1,
  `availability` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `availability` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `restaurant_id` (`restaurant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,1,'Classic Cheeseburger','Juicy beef patty with cheddar, pickles, and signature burger sauce.',149.00,'uploads/menu/classic cheeseburger.png','fastfood',1,'2026-04-08 23:38:40','2026-04-08 23:38:40'),(2,1,'Crispy Chicken Sandwich','Crispy chicken fillet, lettuce, and mayo on a toasted brioche bun.',159.00,'uploads/menu/crispy chicken sandwich.png','fastfood',1,'2026-04-08 23:38:40','2026-04-08 23:38:40'),(3,1,'Double Bacon Burger','Two beef patties, smoky bacon strips, melted cheese, and onion jam.',199.00,'uploads/menu/Double Bacon Burger.png','fastfood',1,'2026-04-08 23:38:40','2026-04-08 23:38:40'),(4,1,'Loaded Fries','Seasoned fries topped with cheese sauce, crispy bits, and spring onions.',119.00,'uploads/menu/Loaded fries with cheese and bacon.png','fastfood',1,'2026-04-08 23:38:40','2026-04-08 23:38:40'),(5,1,'Chicken Nuggets Combo','Eight crispy nuggets with dip, fries, and a regular soft drink.',169.00,'uploads/menu/Crispy chicken nuggets with fries.png','fastfood',1,'2026-04-08 23:38:40','2026-04-08 23:38:40'),(6,3,'Cola Drink','Chilled carbonated cola served over ice for a crisp and refreshing taste.',49.00,'uploads/menu/Cola Drink.png','drinks',1,'2026-04-08 23:38:40','2026-04-08 23:38:40'),(7,3,'Lemon Iced Tea','Freshly brewed iced tea with a splash of lemon, perfectly sweet and refreshing.',59.00,'uploads/menu/Lemon Iced Tea.png','drinks',1,'2026-04-08 23:38:40','2026-04-08 23:38:40'),(8,3,'Chocolate Milkshake','Rich and creamy chocolate milkshake topped with whipped cream.',89.00,'uploads/menu/Chocolate Milkshake.png','drinks',1,'2026-04-08 23:38:40','2026-04-08 23:38:40'),(9,3,'Iced Coffee','Smooth brewed coffee served cold with milk and ice for a bold flavor.',69.00,'uploads/menu/Iced Coffee.png','drinks',1,'2026-04-08 23:38:40','2026-04-08 23:38:40'),(10,3,'Fresh Lemonade','Zesty homemade lemonade with real lemon slices, served ice-cold.',59.00,'uploads/menu/Fresh Lemonade.png','drinks',1,'2026-04-08 23:38:40','2026-04-08 23:38:40'),(11,3,'Cold Beer','Ice-cold premium beer with a smooth, refreshing finish.',99.00,'uploads/menu/Cold Beer.png','drinks',1,'2026-04-08 23:38:40','2026-04-08 23:38:40');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'20260217143000','App\\Database\\Migrations\\CreateUsersTable','default','App',1775720301,1),(2,'20260217143001','App\\Database\\Migrations\\CreateRestaurantsTable','default','App',1775720301,1),(3,'20260217143002','App\\Database\\Migrations\\CreateDriversTable','default','App',1775720301,1),(4,'20260217143003','App\\Database\\Migrations\\CreateOrdersTable','default','App',1775720301,1),(5,'20260220100000','App\\Database\\Migrations\\CreateMenuItemsTable','default','App',1775720301,1),(6,'20260220100001','App\\Database\\Migrations\\AddDiscountPriceToMenuItems','default','App',1775720301,1),(7,'20260225100000','App\\Database\\Migrations\\CreateCustomersTable','default','App',1775720301,1),(8,'20260225100001','App\\Database\\Migrations\\AddApiTokenToDrivers','default','App',1775720301,1),(9,'20260225100002','App\\Database\\Migrations\\AddCustomerFieldsToOrders','default','App',1775720301,1),(10,'20260225100003','App\\Database\\Migrations\\AddImageToMenuItems','default','App',1775720301,1),(11,'20260302100000','App\\Database\\Migrations\\AddResetTokenToCustomers','default','App',1775720301,1),(12,'20260303100000','App\\Database\\Migrations\\AddLogoAndHoursToRestaurants','default','App',1775720301,1),(13,'20260319120000','App\\Database\\Migrations\\RemoveDiscountPriceFromMenuItems','default','App',1775720301,1),(14,'20260401090000','App\\Database\\Migrations\\AddSyncFieldsToMenuItems','default','App',1775720301,1),(15,'20260401100000','App\\Database\\Migrations\\CreateMenusTable','default','App',1775720301,1),(16,'20260402100000','App\\Database\\Migrations\\CreateOrderFlowTablesAndFields','default','App',1775720301,1),(17,'20260408160000','App\\Database\\Migrations\\RemoveDriverVehicleAndLocationColumns','default','App',1775720301,1),(18,'20260409120000','App\\Database\\Migrations\\AddEstimatedPreparationTimeToOrders','default','App',1775720301,1),(19,'20260409170000','App\\Database\\Migrations\\AddMfaAndJwtFields','default','App',1775749780,2),(20,'20260409183000','App\\Database\\Migrations\\HardenSensitiveUserStorage','default','App',1775749780,2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) unsigned NOT NULL,
  `menu_id` int(11) unsigned DEFAULT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `line_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_status_logs`
--

DROP TABLE IF EXISTS `order_status_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_status_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) unsigned NOT NULL,
  `from_status` varchar(50) DEFAULT NULL,
  `to_status` varchar(50) NOT NULL,
  `changed_by_role` varchar(30) DEFAULT NULL,
  `changed_by_id` int(11) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_status_logs`
--

LOCK TABLES `order_status_logs` WRITE;
/*!40000 ALTER TABLE `order_status_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_status_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(100) NOT NULL,
  `customer_id` int(11) unsigned DEFAULT NULL,
  `customer_name` varchar(255) NOT NULL,
  `restaurant_id` int(11) unsigned NOT NULL,
  `driver_id` int(11) unsigned DEFAULT NULL,
  `delivery_type_id` int(11) unsigned DEFAULT NULL,
  `order_size_category` varchar(20) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `estimated_preparation_time` int(11) unsigned DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `delivery_address` text DEFAULT NULL,
  `items` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurants`
--

DROP TABLE IF EXISTS `restaurants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restaurants` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `opening_hours` text DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurants`
--

LOCK TABLES `restaurants` WRITE;
/*!40000 ALTER TABLE `restaurants` DISABLE KEYS */;
INSERT INTO `restaurants` VALUES (1,2,'Burger ng Mama Mo',NULL,NULL,NULL,'approved',1,'2026-04-09 07:38:40','2026-04-09 07:38:40'),(2,3,'Laurel\'s Kitchen',NULL,NULL,NULL,'approved',1,'2026-04-09 07:38:40','2026-04-09 07:38:40'),(3,4,'Palamig ni Admiral Kim',NULL,NULL,NULL,'approved',1,'2026-04-09 07:38:40','2026-04-09 07:38:40');
/*!40000 ALTER TABLE `restaurants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'restaurant',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_hash` char(64) DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `mfa_enabled` tinyint(1) DEFAULT 1,
  `login_otp_code` varchar(6) DEFAULT NULL,
  `login_otp_hash` char(64) DEFAULT NULL,
  `login_otp_expires` datetime DEFAULT NULL,
  `token_version` int(11) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@example.com','$2y$10$CHHBCzWKYKLO9DCrLMisr.5LvxVjc8Ql6GlkQsizt9kUMPCJKiB.G','admin',1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0),(2,'restaurant@example.com','$2y$10$9f3WhtzKka.cc8uNcJcQ8.Mp3Td1KI5tOtYsyasJb6u1PEXYqQmEu','restaurant',1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0),(3,'vesterlaurel@gmail.com','$2y$10$7aOjFX4FXW/z8gfIrnjqxOfBKS0vOcroUCnCLFwchWsZnOkBT4GHu','restaurant',1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0),(4,'owner2@example.com','$2y$10$ocqu4L4vzDf7RAKXj824uOKD1G.S6X9pjTLk2epwMdX6xt2NisjHS','restaurant',1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'fooddash_db'
--

--
-- Dumping routines for database 'fooddash_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-09 23:50:38
